<?php
// classes.phpで定義されていてこれは使われていない。
//class MainCartPageBase extends WebPage{
//
//    /**
//     * @override HTMLPage::getTemplateFilePath()
//     */
//    function getTemplateFilePath(){
//
//    }
//}
