<?php 
/**
 * @class Help.IndexPage
 * @date 2008-12-24T18:43:13+09:00
 * @author SOY2HTMLFactory
 */ 
class IndexPage extends WebPage{
	
	function __construct(){
		parent::__construct();

	}
}
?>